package ir.obd.diag

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import kotlin.concurrent.thread

data class Fault(val code: String, val pending: Boolean)

class Vm : ViewModel() {
    private val logBuf = ArrayDeque<String>()
    var logText by mutableStateOf("")
    private fun addLog(s: String) {
        synchronized(logBuf) {
            logBuf.addLast(s)
            if (logBuf.size > 120) logBuf.removeFirst()
            logText = logBuf.joinToString("\n")
        }
    }

    private val elm = Elm327 { addLog(it) }

    var status by mutableStateOf("متصل نیستید")
    var connected by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var protocol by mutableStateOf("")
    var adapter by mutableStateOf("")
    var carIdx by mutableStateOf(0)
    var devices by mutableStateOf(listOf<BluetoothDevice>())
    var supported by mutableStateOf(listOf<Pid>())
    val values = mutableStateMapOf<Int, Float>()
    var voltage by mutableStateOf<Float?>(null)
    var runMin by mutableStateOf(0f)
    var o2range by mutableStateOf<Float?>(null)
    private var engineStart = 0L
    private val o2hist = ArrayList<Float>()
    fun ctx() = Ctx(values[0x0C], values[0x0D], values[0x05], runMin, o2range)
    var faults by mutableStateOf(listOf<Fault>())
    var faultMsg by mutableStateOf("")
    @Volatile var live = false
    private var liveRunning = false

    fun refresh(ctx: Context) {
        devices = try {
            ctx.getSystemService(BluetoothManager::class.java)?.adapter?.bondedDevices?.toList() ?: emptyList()
        } catch (e: SecurityException) { emptyList() }
    }

    fun connect(d: BluetoothDevice) {
        if (busy) return
        busy = true; connected = false; live = false
        thread {
            try {
                status = "در حال اتصال به آداپتور…"
                elm.connect(d); elm.init()
                adapter = elm.cmd("ATI")
                status = "در حال شناسایی پروتکل خودرو…"
                if (!elm.findProtocol(Obd.cars[carIdx].protocols)) {
                    status = "آداپتور وصل است ولی ECU جواب نمی‌دهد. سوئیچ را روی ON ببرید و دوباره امتحان کنید."
                    return@thread
                }
                protocol = elm.cmd("ATDP")
                val s = elm.supportedPids()
                supported = Obd.pids.filter { it.id in s }
                status = "متصل شد ✅"
                connected = true
            } catch (e: Exception) {
                status = "خطا در اتصال: ${e.message}"
            } finally { busy = false }
        }
    }

    fun disconnect() {
        live = false; connected = false; elm.close(); status = "متصل نیستید"
    }

    fun startLive() {
        live = true
        if (liveRunning || !connected) return
        liveRunning = true
        thread {
            try {
                while (live && connected) {
                    for (p in supported) {
                        if (!live) break
                        elm.mode01(p.id)?.let { d ->
                            val x = p.calc(d)
                            values[p.id] = x
                            if (p.id == 0x0C) {
                                if (x > 300f) { if (engineStart == 0L) engineStart = System.currentTimeMillis() } else engineStart = 0L
                                runMin = if (engineStart == 0L) 0f else (System.currentTimeMillis() - engineStart) / 60000f
                            }
                            if (p.id == 0x14) {
                                o2hist.add(x); if (o2hist.size > 25) o2hist.removeAt(0)
                                o2range = if (o2hist.size >= 10) o2hist.max() - o2hist.min() else null
                            }
                        }
                    }
                    elm.voltage()?.let { voltage = it }
                }
            } catch (e: Exception) {
                connected = false; status = "ارتباط قطع شد"
            } finally { liveRunning = false }
        }
    }

    fun readFaults() {
        if (busy) return
        busy = true
        thread {
            try {
                val st = elm.readDtc("03").map { Fault(it, false) }
                val pe = elm.readDtc("07").map { Fault(it, true) }
                faults = st + pe
                faultMsg = if (faults.isEmpty()) "هیچ خطایی ثبت نشده ✅" else "${faults.size} خطا پیدا شد"
            } catch (e: Exception) { faultMsg = "خطا: ${e.message}" } finally { busy = false }
        }
    }

    fun clearFaults() {
        if (busy) return
        busy = true
        thread {
            try {
                faultMsg = if (elm.clearDtc()) "دستور پاک کردن ارسال شد؛ دوباره «خواندن» را بزنید" else "ECU پاسخ تأیید نداد"
                faults = emptyList()
            } catch (e: Exception) { faultMsg = "خطا: ${e.message}" } finally { busy = false }
        }
    }

    override fun onCleared() { live = false; elm.close() }
}
