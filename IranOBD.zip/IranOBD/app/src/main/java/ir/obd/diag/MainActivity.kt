package ir.obd.diag

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.abs
import kotlin.math.roundToInt

private val Bg = Color(0xFF0D1117)
private val CardBg = Color(0xFF171E2B)
private val Accent = Color(0xFF2DD4BF)
private val Warn = Color(0xFFF59E0B)
private val Bad = Color(0xFFEF4444)
private val Muted = Color(0xFF8B96A8)

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    private val perm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) perm.launch(Manifest.permission.BLUETOOTH_CONNECT)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent, onPrimary = Color.Black, background = Bg, onBackground = Color.White,
                    surface = Color(0xFF111723), onSurface = Color.White,
                    surfaceVariant = CardBg, onSurfaceVariant = Color.White,
                ),
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Root(viewModel(), tick)
                }
            }
        }
    }
}

@Composable
fun Root(vm: Vm, tick: Int) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("📡" to "اتصال", "🎛" to "داشبورد", "⚠" to "خطاها", "📚" to "راهنما", "ℹ" to "اطلاعات")
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Text(t.first, fontSize = 20.sp) }, label = { Text(t.second) })
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> ConnectScreen(vm, tick) { tab = 1 }
                1 -> Dashboard(vm)
                2 -> Faults(vm)
                3 -> Guide(vm)
                else -> InfoScreen(vm)
            }
        }
    }
}

@Composable
fun ConnectScreen(vm: Vm, tick: Int, onConnected: () -> Unit) {
    val ctx = LocalContext.current
    LaunchedEffect(tick) { vm.refresh(ctx) }
    LaunchedEffect(vm.connected) { if (vm.connected) onConnected() }
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("دیاگ ایران", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Accent)
        Text(vm.status, color = if (vm.connected) Accent else Muted)
        Box {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
                Text("🚗  ${Obd.cars[vm.carIdx].name}")
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                Obd.cars.forEachIndexed { i, c ->
                    DropdownMenuItem(text = { Text(c.name) }, onClick = { vm.carIdx = i; open = false })
                }
            }
        }
        Text("آداپتور ELM327 را اول در تنظیمات بلوتوث گوشی جفت کنید (رمز: 1234 یا 0000)، سوئیچ را باز کنید، بعد آن را اینجا انتخاب کنید.",
            color = Muted, fontSize = 13.sp)
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (vm.connected) Button(onClick = { vm.disconnect() }, modifier = Modifier.fillMaxWidth()) { Text("قطع اتصال") }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.devices) { d ->
                val name = try { d.name } catch (e: SecurityException) { null } ?: d.address
                Card(Modifier.fillMaxWidth().clickable(enabled = !vm.busy) { vm.connect(d) }) {
                    Column(Modifier.padding(14.dp)) {
                        Text("📶  $name", fontWeight = FontWeight.Bold)
                        Text(d.address, color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

private fun lvlColor(l: Level) = when (l) {
    Level.OK -> Color(0xFF22C55E); Level.INFO -> Color(0xFF60A5FA); Level.WARN -> Warn; Level.BAD -> Bad
}

private fun insightOf(p: Pid, vm: Vm, c: Ctx, s: Spec): Insight? {
    val v = if (p.id == -1) vm.voltage else vm.values[p.id]
    return v?.let { Knowledge.insight(p.id, it, c, s) }
}

@Composable
fun Dashboard(vm: Vm) {
    DisposableEffect(vm.connected) { vm.startLive(); onDispose { vm.live = false } }
    if (!vm.connected) { Center("ابتدا از تب «اتصال» به خودرو وصل شوید"); return }
    val spec = Obd.cars[vm.carIdx].spec
    val c = vm.ctx()
    var sel by remember { mutableStateOf<Pid?>(null) }
    val rpm = vm.supported.find { it.id == 0x0C }
    val spd = vm.supported.find { it.id == 0x0D }
    val rest = vm.supported.filter { it.id != 0x0C && it.id != 0x0D }
    val all = listOf(Obd.voltPid) + vm.supported
    val ins = all.mapNotNull { p -> insightOf(p, vm, c, spec)?.let { p to it } }
    LazyVerticalGrid(
        columns = GridCells.Fixed(2), contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { Summary(ins) }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                rpm?.let { p -> GaugeBox(p, vm.values[p.id] ?: 0f, insightOf(p, vm, c, spec)) { sel = p } }
                spd?.let { p -> GaugeBox(p, vm.values[p.id] ?: 0f, insightOf(p, vm, c, spec)) { sel = p } }
            }
        }
        item { Tile(Obd.voltPid, vm.voltage, insightOf(Obd.voltPid, vm, c, spec)) { sel = Obd.voltPid } }
        items(rest) { p -> Tile(p, vm.values[p.id], insightOf(p, vm, c, spec)) { sel = p } }
        if (vm.supported.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) {
            Text("این ECU داده زنده استاندارد نمی‌دهد. لاگ تب «اطلاعات» را بررسی کنید.", color = Muted)
        }
    }
    sel?.let { InfoDialog(it, spec) { sel = null } }
}

@Composable
fun Summary(ins: List<Pair<Pid, Insight>>) {
    val bad = ins.filter { it.second.level == Level.BAD }
    val warn = ins.filter { it.second.level == Level.WARN }
    val (icon, title, col) = when {
        bad.isNotEmpty() -> Triple("⛔", "${bad.size} مورد بحرانی", Bad)
        warn.isNotEmpty() -> Triple("⚠️", "${warn.size} هشدار", Warn)
        else -> Triple("✅", "همه‌چیز در محدوده‌ی نرمال است", lvlColor(Level.OK))
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("$icon  $title", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = col)
            (bad + warn).take(3).forEach { Text("• ${it.first.name}: ${it.second.text}", fontSize = 13.sp, color = Muted) }
            Text("برای توضیح کامل هر پارامتر روی آن بزنید", fontSize = 11.sp, color = Muted)
        }
    }
}

@Composable
fun GaugeBox(p: Pid, v: Float, ins: Insight?, onClick: () -> Unit) {
    Column(Modifier.width(165.dp).clickable { onClick() }, horizontalAlignment = Alignment.CenterHorizontally) {
        Gauge(p.name, v, p.max, p.unit)
        if (ins != null && ins.text.isNotEmpty())
            Text("● ${ins.text}", color = lvlColor(ins.level), fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun Gauge(label: String, value: Float, max: Float, unit: String) {
    val f = (value / max).coerceIn(0f, 1f)
    val col = when { f > .85f -> Bad; f > .65f -> Warn; else -> Accent }
    Box(Modifier.size(165.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = 16.dp.toPx()
            val tl = Offset(w / 2, w / 2)
            val sz = Size(size.width - w, size.height - w)
            drawArc(Color(0xFF263042), 135f, 270f, false, tl, sz, style = Stroke(w, cap = StrokeCap.Round))
            drawArc(col, 135f, 270f * f, false, tl, sz, style = Stroke(w, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value.roundToInt().toString(), fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text(unit, color = Muted, fontSize = 12.sp)
            Text(label, fontSize = 13.sp)
        }
    }
}

@Composable
fun Tile(p: Pid, v: Float?, ins: Insight?, onClick: () -> Unit) {
    val f = if (v == null) 0f else ((v - p.min) / (p.max - p.min)).coerceIn(0f, 1f)
    Card(Modifier.fillMaxWidth().clickable { onClick() }) {
        Column(Modifier.padding(14.dp)) {
            Text(p.name, color = Muted, fontSize = 13.sp)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(if (v == null) "—" else if (abs(v) >= 100) v.roundToInt().toString() else "%.1f".format(v),
                    fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(6.dp))
                Text(p.unit, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp))
            }
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(progress = f, modifier = Modifier.fillMaxWidth(), color = if (ins != null) lvlColor(ins.level) else Accent, trackColor = Color(0xFF263042))
            if (ins != null && ins.text.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text("● ${ins.text}", color = lvlColor(ins.level), fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun Section(t: String, b: String) {
    Column {
        Text(t, fontWeight = FontWeight.Bold, color = Accent, fontSize = 13.sp)
        Text(b, fontSize = 14.sp)
    }
}

@Composable
fun InfoDialog(p: Pid, spec: Spec, onClose: () -> Unit) {
    val k = Knowledge.info[p.id]
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("بستن") } },
        title = { Text(p.name) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (k == null) Text("توضیحی برای این پارامتر ثبت نشده است.") else {
                    Section("📖 چیست؟", k.what)
                    Section("✅ مقدار نرمال (${spec.brand})", k.normal(spec))
                    Section("🔺 اگر زیاد بود", k.high)
                    Section("🔻 اگر کم بود", k.low)
                }
            }
        },
    )
}

@Composable
fun Guide(vm: Vm) {
    val spec = Obd.cars[vm.carIdx].spec
    var open by remember { mutableStateOf<Int?>(null) }
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("راهنمای پارامترها — ${spec.brand}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Accent)
                Text(spec.thermoNote, color = Muted, fontSize = 12.sp)
                Text("اعداد این راهنما از منابع تعمیرگاهی و کاتالوگ قطعات (ایرانی و خارجی) جمع‌آوری شده و «حدود معمول» است، نه دفترچه‌ی رسمی کارخانه. اگر عددی با دفترچه‌ی خودرو فرق داشت، دفترچه معتبرتر است.",
                    color = Muted, fontSize = 12.sp)
            }
        }
        items(listOf(Obd.voltPid) + Obd.pids) { p ->
            val k = Knowledge.info[p.id]
            Card(Modifier.fillMaxWidth().clickable { open = if (open == p.id) null else p.id }) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(p.name, fontWeight = FontWeight.Bold)
                    if (k != null) {
                        Text(k.what, color = Muted, fontSize = 13.sp)
                        if (open == p.id) {
                            Section("✅ مقدار نرمال (${spec.brand})", k.normal(spec))
                            Section("🔺 اگر زیاد بود", k.high)
                            Section("🔻 اگر کم بود", k.low)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Faults(vm: Vm) {
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { vm.readFaults() }, enabled = vm.connected && !vm.busy, modifier = Modifier.weight(1f)) { Text("خواندن خطاها") }
            OutlinedButton(onClick = { confirm = true }, enabled = vm.connected && !vm.busy, modifier = Modifier.weight(1f)) { Text("پاک کردن") }
        }
        if (!vm.connected) Text("ابتدا به خودرو وصل شوید", color = Muted)
        Text(vm.faultMsg, color = Muted)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.faults) { f ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(f.code, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace,
                            color = if (f.pending) Warn else Bad)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(Obd.describe(f.code))
                            Text(if (f.pending) "در انتظار تأیید" else "ثابت (ذخیره‌شده)", color = Muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("پاک کردن خطاها؟") },
        text = { Text("خطاهای ذخیره‌شده و چراغ چک پاک می‌شود. اگر عیب برطرف نشده باشد دوباره برمی‌گردد.") },
        confirmButton = { TextButton(onClick = { confirm = false; vm.clearFaults() }) { Text("پاک کن") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("انصراف") } },
    )
}

@Composable
fun InfoScreen(vm: Vm) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("خودرو: ${Obd.cars[vm.carIdx].name}")
        Text("آداپتور: ${vm.adapter.ifEmpty { "—" }}")
        Text("پروتکل: ${vm.protocol.ifEmpty { "—" }}")
        Text("تعداد پارامترهای پشتیبانی‌شده: ${vm.supported.size}")
        Text("لاگ ارتباط (برای عیب‌یابی؛ می‌توانید کپی کنید):", color = Muted)
        SelectionContainer {
            Text(vm.logText, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Muted)
        }
    }
}

@Composable
fun Center(t: String) = Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
    Text(t, color = Muted, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
}
