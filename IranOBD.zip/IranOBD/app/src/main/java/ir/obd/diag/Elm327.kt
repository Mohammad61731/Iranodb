package ir.obd.diag

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/** Talks to an ELM327 adapter over Bluetooth classic (SPP). */
class Elm327(private val log: (String) -> Unit) {
    private var socket: BluetoothSocket? = null
    private var inp: InputStream? = null
    private var out: OutputStream? = null
    var isCan = false

    @SuppressLint("MissingPermission")
    fun connect(d: BluetoothDevice) {
        close()
        val s = d.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
        s.connect()
        socket = s; inp = s.inputStream; out = s.outputStream
    }

    fun close() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null
    }

    @Synchronized
    fun cmd(c: String, timeoutMs: Long = 3000): String {
        val o = out ?: throw IllegalStateException("اتصال برقرار نیست")
        val i = inp ?: throw IllegalStateException("اتصال برقرار نیست")
        while (i.available() > 0) i.read()
        o.write((c + "\r").toByteArray()); o.flush()
        val sb = StringBuilder()
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (i.available() > 0) {
                val ch = i.read()
                if (ch == '>'.code) break
                sb.append(ch.toChar())
            } else Thread.sleep(8)
        }
        val r = sb.toString().split('\r', '\n').map { it.trim() }
            .filter { it.isNotEmpty() && it != c }.joinToString("\n")
        log("$c  ←  ${r.replace("\n", " | ")}")
        return r
    }

    fun init() {
        cmd("ATZ", 5000); cmd("ATE0"); cmd("ATL0"); cmd("ATS0"); cmd("ATH0"); cmd("ATAT1")
    }

    /** Tries each ELM protocol number in order until the ECU answers 0100. */
    fun findProtocol(order: List<String>): Boolean {
        for (p in order) {
            cmd("ATSP$p")
            val r = cmd("0100", 20000).replace(" ", "")
            if (r.contains("4100")) {
                val n = cmd("ATDPN").trim().removePrefix("A").toIntOrNull(16) ?: 0
                isCan = n >= 6
                return true
            }
        }
        return false
    }

    fun mode01(pid: Int): IntArray? {
        val p = "%02X".format(pid)
        for (line in cmd("01$p", 2500).split("\n")) {
            val h = line.replace(" ", "")
            val k = h.indexOf("41$p")
            if (k >= 0) {
                return h.substring(k + 4).chunked(2).filter { it.length == 2 }
                    .mapNotNull { it.toIntOrNull(16) }.toIntArray()
            }
        }
        return null
    }

    fun supportedPids(): Set<Int> {
        val s = mutableSetOf<Int>()
        var base = 0
        while (base <= 0x40) {
            val d = mode01(base) ?: break
            if (d.size < 4) break
            for (i in 0 until 32) if (((d[i / 8] shr (7 - i % 8)) and 1) == 1) s.add(base + i + 1)
            if (!s.contains(base + 0x20)) break
            base += 0x20
        }
        return s
    }

    /** mode "03" = stored codes, "07" = pending codes. */
    fun readDtc(mode: String): List<String> {
        val resp = "4" + mode.substring(1)
        val lines = cmd(mode, 8000).split("\n").map { it.replace(" ", "") }
        val tag = Regex("^[0-9]:")
        val multi = lines.any { tag.containsMatchIn(it) }
        val blocks = if (multi) listOf(lines.filter { tag.containsMatchIn(it) }.joinToString("") { it.substring(2) }) else lines
        val codes = mutableListOf<String>()
        for (b in blocks) {
            if (!b.startsWith(resp)) continue
            var h = b.substring(2)
            if (isCan && h.length >= 2) h = h.substring(2)
            h.chunked(4).forEach { if (it.length == 4 && it != "0000") codes.add(Obd.decodeDtc(it)) }
        }
        return codes.distinct()
    }

    fun clearDtc(): Boolean = cmd("04", 6000).replace(" ", "").contains("44")

    fun voltage(): Float? = cmd("ATRV", 1500).removeSuffix("V").trim().toFloatOrNull()
}
