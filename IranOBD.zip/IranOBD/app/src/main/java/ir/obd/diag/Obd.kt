package ir.obd.diag

private fun IntArray.b(i: Int) = getOrElse(i) { 0 }

data class Pid(
    val id: Int, val name: String, val unit: String, val max: Float,
    val min: Float = 0f, val calc: (IntArray) -> Float,
)

/** protocols = ELM327 "ATSP" numbers, tried in order (0 = automatic). */
data class Car(val name: String, val protocols: List<String>, val spec: Spec)

object Obd {
    private val order = listOf("0", "5", "4", "3", "6")

    val cars = listOf(
        Car("تشخیص خودکار (هر خودرو)", order, Specs.generic),
        Car("پراید ۱۱۱", order, Specs.pride), Car("پراید ۱۳۱", order, Specs.pride),
        Car("پراید ۱۳۲", order, Specs.pride), Car("پراید ۱۴۱", order, Specs.pride),
        Car("صبا", order, Specs.pride),
        Car("پژو ۴۰۵ GLX انژکتوری", order, Specs.p405), Car("پژو ۴۰۵ SLX انژکتوری", order, Specs.p405),
        Car("پژو ۴۰۵ دوگانه‌سوز", order, Specs.p405),
    )

    val voltPid = Pid(-1, "ولتاژ باتری", "V", 15f, 9f) { 0f }

    val pids = listOf(
        Pid(0x0C, "دور موتور", "rpm", 8000f) { (it.b(0) * 256 + it.b(1)) / 4f },
        Pid(0x0D, "سرعت خودرو", "km/h", 200f) { it.b(0).toFloat() },
        Pid(0x05, "دمای آب موتور", "°C", 130f, -40f) { it.b(0) - 40f },
        Pid(0x0F, "دمای هوای ورودی", "°C", 80f, -40f) { it.b(0) - 40f },
        Pid(0x5C, "دمای روغن", "°C", 150f, -40f) { it.b(0) - 40f },
        Pid(0x04, "بار موتور", "%", 100f) { it.b(0) * 100f / 255f },
        Pid(0x11, "دریچه گاز", "%", 100f) { it.b(0) * 100f / 255f },
        Pid(0x10, "جریان هوا (MAF)", "g/s", 250f) { (it.b(0) * 256 + it.b(1)) / 100f },
        Pid(0x0B, "فشار منیفولد (MAP)", "kPa", 255f) { it.b(0).toFloat() },
        Pid(0x0E, "زمان‌بندی جرقه", "°", 64f, -64f) { it.b(0) / 2f - 64f },
        Pid(0x06, "تنظیم سوخت کوتاه‌مدت", "%", 25f, -25f) { (it.b(0) - 128) * 100f / 128f },
        Pid(0x07, "تنظیم سوخت بلندمدت", "%", 25f, -25f) { (it.b(0) - 128) * 100f / 128f },
        Pid(0x14, "سنسور اکسیژن ۱", "V", 1.1f) { it.b(0) / 200f },
        Pid(0x15, "سنسور اکسیژن ۲", "V", 1.1f) { it.b(0) / 200f },
        Pid(0x0A, "فشار سوخت", "kPa", 765f) { it.b(0) * 3f },
        Pid(0x2F, "سطح سوخت", "%", 100f) { it.b(0) * 100f / 255f },
        Pid(0x42, "ولتاژ ECU", "V", 15f, 9f) { (it.b(0) * 256 + it.b(1)) / 1000f },
    )

    fun decodeDtc(h: String): String {
        val a = h.substring(0, 2).toInt(16)
        val b = h.substring(2, 4).toInt(16)
        return "%c%d%X%02X".format("PCBU"[a shr 6], (a shr 4) and 3, a and 15, b)
    }

    fun describe(code: String): String = dtc[code] ?: "توضیح این کد هنوز در برنامه نیست"

    private val dtc = mapOf(
        "P0100" to "مدار سنسور جریان هوا (MAF)",
        "P0105" to "مدار سنسور فشار منیفولد (MAP)",
        "P0110" to "مدار سنسور دمای هوای ورودی",
        "P0115" to "مدار سنسور دمای آب موتور",
        "P0120" to "مدار سنسور موقعیت دریچه گاز (TPS)",
        "P0130" to "مدار سنسور اکسیژن (قبل کاتالیست)",
        "P0135" to "گرم‌کن سنسور اکسیژن (قبل کاتالیست)",
        "P0170" to "اشکال در تنظیم سوخت",
        "P0201" to "مدار انژکتور سیلندر ۱", "P0202" to "مدار انژکتور سیلندر ۲",
        "P0203" to "مدار انژکتور سیلندر ۳", "P0204" to "مدار انژکتور سیلندر ۴",
        "P0300" to "ناموفقی احتراق (چند سیلندر)",
        "P0301" to "ناموفقی احتراق سیلندر ۱", "P0302" to "ناموفقی احتراق سیلندر ۲",
        "P0303" to "ناموفقی احتراق سیلندر ۳", "P0304" to "ناموفقی احتراق سیلندر ۴",
        "P0325" to "مدار سنسور ضربه (کنوک)",
        "P0335" to "مدار سنسور دور موتور (میل‌لنگ)",
        "P0340" to "مدار سنسور فاز (میل‌سوپاپ)",
        "P0420" to "بازدهی کاتالیست پایین‌تر از حد مجاز",
        "P0443" to "مدار شیر کنیستر (EVAP)",
        "P0500" to "مدار سنسور سرعت خودرو",
        "P0505" to "سیستم کنترل دور آرام",
        "P0560" to "ولتاژ سیستم نامناسب",
        "P0605" to "خطای حافظه ECU",
        "P0650" to "مدار چراغ MIL (چک)",
    )
}
